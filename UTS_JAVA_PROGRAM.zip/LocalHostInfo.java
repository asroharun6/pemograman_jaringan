import java.net.InetAddress;

public class LocalHostInfo {
    public static void main(String[] args) {
        try {
            InetAddress localHost = InetAddress.getLocalHost();
            System.out.println("Nama Komputer Lokal: " + localHost.getHostName());
            System.out.println("IP Address Lokal: " + localHost.getHostAddress());
        } catch (Exception e) {
            System.out.println("Tidak dapat menemukan informasi host lokal.");
            e.printStackTrace();
        }
    }
}
