import java.net.URL;

public class URLExtractor {
    public static void main(String[] args) {
        try {
            URL url = new URL("https://analysis.daarulyusronulmubiin.sch.id/chat/upload/6575431428860.png");

            System.out.println("Protocol: " + url.getProtocol());
            System.out.println("Host: " + url.getHost());
            System.out.println("Port: " + url.getPort());
            System.out.println("Path: " + url.getPath());
            System.out.println("Query: " + url.getQuery());
            System.out.println("File: " + url.getFile());
            System.out.println("Ref: " + url.getRef());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
