import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    // Menetapkan port server untuk mendengarkan koneksi
    private static final int PORT = 1234;
    // Membuat pool thread untuk mengelola klien secara paralel
    private static ExecutorService pool = Executors.newFixedThreadPool(4);
    // Daftar untuk menyimpan semua client handler
    private static List<ClientHandler> clients = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) throws IOException {
        // Membuat server socket yang mendengarkan pada port tertentu
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Server is listening on port " + PORT);

        // Loop tanpa akhir untuk menerima koneksi klien
        while (true) {
            try {
                // Menerima koneksi klien
                Socket clientSocket = serverSocket.accept();
                // Membuat client handler baru untuk mengelola koneksi
                ClientHandler clientThread = new ClientHandler(clientSocket);
                // Menambahkan client handler ke daftar
                clients.add(clientThread);
                // Menjalankan client handler di thread terpisah
                pool.execute(clientThread);
            } catch (IOException e) {
                System.err.println("Error in connection attempt.");
            }
        }
    }

    // Metode untuk broadcast pesan ke semua klien
    static void broadcastMessage(String message) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                // Mengirim pesan jika socket klien tidak tertutup
                if (!client.getSocket().isClosed()) {
                    client.sendMessage(message);
                }
            }
        }
    }

    // Metode yang dipanggil ketika pengguna baru bergabung
    static void userJoined(String userName) {
        // Membuat pesan yang menunjukkan pengguna baru bergabung
        String joinMessage = userName + " has joined the chat!";
        System.out.println(joinMessage);
        // Broadcast pesan tersebut ke semua klien
        broadcastMessage(joinMessage);
    }

    // Metode untuk menghapus klien dari daftar
    static void removeClient(ClientHandler client) {
        clients.remove(client);
    }
}

// ClientHandler mengelola koneksi untuk setiap klien
class ClientHandler implements Runnable {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String userName;

    // Konstruktor ClientHandler
    public ClientHandler(Socket socket) throws IOException {
        this.socket = socket;
        // Membuat BufferedReader untuk membaca input dari klien
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        // Membuat PrintWriter untuk mengirim output ke klien
        out = new PrintWriter(socket.getOutputStream(), true);
    }

    // Getter untuk socket
    public Socket getSocket() {
        return socket;
    }

    // Mengirim pesan ke klien
    public void sendMessage(String message) {
        out.println(message);
    }

    @Override
    public void run() {
        try {
            // Membaca nama pengguna dari klien
            userName = in.readLine();
            // Memberitahu semua klien bahwa pengguna baru telah bergabung
            Server.userJoined(userName);

            // Membaca pesan dari klien dan broadcast
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                String message = "[" + userName + "]: " + inputLine;
                System.out.println(message);
                Server.broadcastMessage(message);
            }
        } catch (IOException e) {
            System.err.println("Error in client communication: " + userName);
        } finally {
            // Menutup sumber daya ketika klien terputus
            closeResources();
        }
    }

    // Menutup BufferedReader, PrintWriter, dan Socket
    private void closeResources() {
        try {
            in.close();
            out.close();
            socket.close();
            // Menghapus klien dari daftar
            Server.removeClient(this);
        } catch (IOException e) {
            System.err.println("Error closing client connection: " + userName);
        }
    }
}
