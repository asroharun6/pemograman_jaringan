import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    // Mendefinisikan alamat IP dan port server untuk koneksi
    private static final String SERVER_IP = "127.0.0.1";
    private static final int SERVER_PORT = 1234;

    public static void main(String[] args) {
        // Menampilkan pesan selamat datang saat klien dimulai
        System.out.println("Welcome to the Chat Client");

        try {
            // Membuat koneksi socket ke server menggunakan IP dan port yang ditentukan
            Socket socket = new Socket(SERVER_IP, SERVER_PORT);
            // Inisialisasi PrintWriter untuk mengirim pesan ke server
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            // Inisialisasi BufferedReader untuk membaca pesan dari server
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            // Scanner untuk membaca input dari pengguna
            Scanner scanner = new Scanner(System.in);

            // Meminta pengguna memasukkan nama pengguna mereka
            System.out.print("Enter your username: ");
            String userName = scanner.nextLine();
            // Mengirim nama pengguna ke server
            out.println(userName);

            // Membuat thread baru untuk membaca pesan dari server secara asinkron
            Thread readThread = new Thread(new ReadMessage(in, userName));
            readThread.start();

            // Loop untuk membaca pesan dari pengguna dan mengirimkannya ke server
            String userInput;
            while ((userInput = scanner.nextLine()) != null) {
                // Jika pengguna mengetik 'exit', keluar dari loop
                if (userInput.equalsIgnoreCase("exit")) {
                    break;
                }
                // Mengirim pesan yang diketik pengguna ke server
                out.println(userInput);
            }

            // Menghentikan thread pembacaan ketika pengguna keluar
            readThread.interrupt();
        } catch (IOException e) {
            // Menangani kesalahan koneksi
            System.err.println("Error connecting to the server: " + e.getMessage());
        }
    }
}

// Kelas untuk membaca dan menampilkan pesan dari server
class ReadMessage implements Runnable {
    private BufferedReader reader;
    private String userName;

    public ReadMessage(BufferedReader reader, String userName) {
        this.reader = reader;
        this.userName = userName;
    }

    @Override
    public void run() {
        try {
            String response;
            // Membaca pesan dari server
            while ((response = reader.readLine()) != null) {
                // Memfilter untuk tidak menampilkan pesan yang dikirim oleh pengguna itu sendiri
                if (!response.startsWith("[" + userName + "]")) {
                    System.out.println(response);
                }
            }
        } catch (IOException e) {
            // Menangani kesalahan saat membaca dari server
            System.err.println("Error reading from server: " + e.getMessage());
        }
    }
}
